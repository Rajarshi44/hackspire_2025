export const firebaseConfig = {
  "projectId": "studio-1512856463-cb519",
  "appId": "1:809320154283:web:eb935fcf5224cd011fe3ee",
  "apiKey": "AIzaSyAlySz07mx0GfgZhq9c-X0BMXBe-eBgoDQ",
  "authDomain": "studio-1512856463-cb519.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "809320154283"
};
